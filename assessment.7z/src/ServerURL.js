export const serverUrl = "https://reqres.in/";
